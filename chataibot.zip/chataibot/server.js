const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(bodyParser.json());

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

function isValidDate(dateString) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateString)) return false;
  const date = new Date(dateString);
  if (Number.isNaN(date.getTime())) return false;
  const [year, month, day] = dateString.split('-').map(Number);
  const valid = date.getUTCFullYear() === year && date.getUTCMonth() + 1 === month && date.getUTCDate() === day;
  if (!valid) return false;
  const today = new Date();
  today.setHours(0,0,0,0);
  return date >= today;
}

function randomReply(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

let bookings = [];
const maxTickets = 10;
const completedBookings = {};

const supportedLanguages = ['Marathi', 'Hindi', 'Punjabi', 'Malayalam', 'English'];

const formatLanguageKey = (str) => {
  if (!str || typeof str !== 'string') return '';
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};

const messages = {
  English: {
    greeting: "Hello! Which language would you like to talk in?",
    howCanIHelp: "How can I help you today?",
    askName: "Please tell me your name.",
    askTickets: `How many tickets do you want? (1-${maxTickets})`,
    askDate: "Please provide the visit date in YYYY-MM-DD format.",
    askPlace: "Where would you like to visit? Please choose one.",
    confirmBooking: (name,tickets,date,place) => `Great! ✨ Booking ${tickets} tickets for ${name} on ${date} to visit ${place}. Please confirm with YES or cancel with NO.`,
    bookingConfirmed: "Your booking is confirmed! 🎉 Thank you!",
    bookingCancelled: "Booking cancelled. You can start anytime.",
    invalidDate: "Sorry, the date is invalid or in the past. Please input a valid date.",
    invalidTickets: `Please enter a number of tickets between 1 and ${maxTickets}.`
  },
  Marathi: {
    greeting: "नमस्कार! आपण कोणती भाषा बोलू इच्छिता?",
    howCanIHelp: "मी तुम्हाला आज कशी मदत करू शकतो?",
    askName: "कृपया आपले नाव सांगा.",
    askTickets: "तुम्हाला किती तिकीटे हवे आहेत?",
    askDate: "कृपया भेटीचा दिवस YYYY-MM-DD स्वरूपात सांगा.",
    askPlace: "कुठे भेट देऊ इच्छिता? कृपया खालीलपैकी एक निवडा.",
    confirmBooking: (name,tickets,date,place) => `छान! ✨ ${name} साठी ${tickets} तिकीटे ${date} रोजी ${place} साठी नोंदणी करीत आहे. कृपया YES म्हणून पुष्टी करा किंवा NO म्हणून रद्द करा.`,
    bookingConfirmed: "तुमची नोंदणी पुष्टी करण्यात आली आहे! 🎉 धन्यवाद!",
    bookingCancelled: "नोंदणी रद्द करण्यात आली. तुम्हाला कधीही पुन्हा प्रारंभ करता येईल.",
    invalidDate: "वाईट वाटते, दिलेला दिनांक चुकीचा/भूतकाळाचा आहे. कृपया योग्य दिनांक द्या.",
    invalidTickets: `कृपया 1 ते ${maxTickets} दरम्यान तिकीटांची योग्य संख्या द्या.`
  },
  Hindi: {
    greeting: "नमस्ते! आप किस भाषा में बात करना चाहेंगे?",
    howCanIHelp: "मैं आपकी कैसे मदद कर सकता हूँ?",
    askName: "कृपया अपना नाम बताएं।",
    askTickets: "आप कितनी टिकटें लेना चाहते हैं?",
    askDate: "जानकारी के लिए कृपया YYYY-MM-DD फॉर्मेट में तारीख बताएं।",
    askPlace: "आप कहाँ जाना चाहते हैं? कृपया नीचे से चुनें।",
    confirmBooking: (name,tickets,date,place) => `शानदार! ✨ ${name} के लिए ${tickets} टिकटें ${date} को ${place} में बुक की जा रही हैं। कृपया YES कहें पुष्टि करने के लिए या NO कहें रद्द करने के लिए।`,
    bookingConfirmed: "आपकी बुकिंग पुष्टि हो गई है! 🎉 धन्यवाद!",
    bookingCancelled: "बुकिंग रद्द कर दी गई है। आप कभी भी फिर से शुरू कर सकते हैं।",
    invalidDate: "क्षमा करें, तारीख गलत है या पहले की है। कृपया सही तारीख दें।",
    invalidTickets: `कृपया 1 से ${maxTickets} के बीच टिकटों की संख्या दें।`
  },
  Punjabi: {
    greeting: "ਸਤ ਸ੍ਰੀ ਅਕਾਲ! ਤੁਸੀਂ ਕਿਹੜੀ ਭਾਸ਼ਾ ਵਿਚ ਗੱਲ ਕਰਨਾ ਚਾਹੁੰਦੇ ਹੋ?",
    howCanIHelp: "ਮੈਂ ਤੁਹਾਡੀ ਕਿਵੇਂ ਮਦਦ ਕਰ ਸਕਦਾ ਹਾਂ?",
    askName: "ਕਿਰਪਾ ਕਰਕੇ ਆਪਣਾ ਨਾਮ ਦੱਸੋ।",
    askTickets: "ਤੁਸੀਂ ਕਿੰਨੀ ਟਿਕਟਾਂ ਲੈਣੀ ਚਾਹੁੰਦੇ ਹੋ?",
    askDate: "ਕਿਰਪਾ ਕਰਕੇ YYYY-MM-DD ਫਾਰਮੈਟ ਵਿੱਚ ਦਿਨਾਂਕ ਦੱਸੋ।",
    askPlace: "ਤੁਸੀਂ ਕਿੱਥੇ ਜਾਣਾ ਚਾਹੁੰਦੇ ਹੋ? ਕਿਰਪਾ ਕਰਕੇ ਹੇਠਾਂੋਂ ਚੁਣੋ।",
    confirmBooking: (name,tickets,date,place) => `ਵਧੀਆ! ✨ ${name} ਲਈ ${tickets} ਟਿਕਟਾਂ ${date} ਨੂੰ ${place} ਵਿੱਚ ਬੁਕ ਕੀਤੀਆਂ ਜਾ ਰਹੀਆਂ ਹਨ। ਕਿਰਪਾ ਕਰਕੇ ਪੁਸ਼ਟੀ ਲਈ YES ਕਰੋ ਜਾਂ ਰੱਦ ਕਰਨ ਲਈ NO।`,
    bookingConfirmed: "ਤੁਹਾਡੀ ਬੁਕਿੰਗ ਪੁਸ਼ਟੀ ਹੋ ਗਈ ਹੈ! 🎉 ਧੰਨਵਾਦ!",
    bookingCancelled: "ਬੁਕਿੰਗ ਰੱਦ ਕਰ ਦਿੱਤੀ ਗਈ ਹੈ। ਤੁਸੀਂ ਕਦੇ ਵੀ ਫਿਰ ਸ਼ੁਰੂ ਕਰ ਸਕਦੇ ਹੋ।",
    invalidDate: "ਮਾਫ਼ ਕਰਨਾ, ਦਿਤੀ ਗਈ ਤਾਰੀਖ ਗਲਤ ਜਾਂ ਪਹਿਲਾਂ ਦੀ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ ਸਹੀ ਤਾਰੀਖ ਦਿਓ।",
    invalidTickets: `ਕਿਰਪਾ ਕਰਕੇ 1 ਤੋਂ ${maxTickets} ਵਿਚਕਾਰ ਟਿਕਟਾਂ ਦੀ ਗਿਣਤੀ ਦਿਓ।`
  },
  Malayalam: {
    greeting: "[translate:നമസ്കാരം! നിങ്ങൾക്ക് ഏത് ഭാഷയിൽ സംസാരിക്കണമെന്നാണ് ഇച്ഛിക്കുന്നത്?]",
    howCanIHelp: "[translate:ഞാൻ നിങ്ങളെ എങ്ങനെ സഹായിക്കാം?]",
    askName: "[translate:ദയവായി നിങ്ങളുടെ പേര് പറയാമോ?]",
    askTickets: "[translate:നിങ്ങൾക്ക് എത്ര ടിക്കറ്റ് വേണമെന്നാണ് പറയാൻ പോകുന്നത്?]",
    askDate: "[translate:സന്ദർശന തിയതി YYYY-MM-DD ഫോര്മാറ്റിൽ നൽകുക.]",
    askPlace: "[translate:സന്ദർശിക്കാൻ നിങ്ങൾക്ക് ആഗ്രഹിക്കുന്നിടം തിരഞ്ഞെടുക്കുക.]",
    confirmBooking: (name,tickets,date,place) => `[translate:അതിര്‍ത്തിയിടാം!] ✨ ${name} [translate:ക്കായി] ${tickets} [translate:ടിക്കറ്റുകൾ] ${date} [translate:ന്] ${place} [translate:നെത്തുന്നത് ബുക്ക് ചെയ്യുന്നു.] [translate:ദയവായി സ്ഥിരീകരിക്കാൻ YES എന്നും മറുപടി പറഞ്ഞ്, റദ്ദാക്കാൻ NO എന്നും മറുപടി പറയൂ.]`,
    bookingConfirmed: "[translate:നിങ്ങളുടെ ബുക്കിംഗ് സ്ഥിരീകരിച്ചിരിക്കുന്നു!] 🎉 [translate:നന്ദി!]",
    bookingCancelled: "[translate:ബുക്കിംഗ് റദ്ദാക്കി. നിങ്ങൾക്ക് എവിടെ വേണെയോ തുടർന്നു ആരംഭിക്കാം.]",
    invalidDate: "[translate:ക്ഷമിക്കണം, നൽകിയ തീയതി തെറ്റായതാണ് അല്ലെങ്കിൽ പഴയ തീയതിയാണ്. ദയവായി ശരിയായ തീയതി നൽകുക.]",
    invalidTickets: `[translate:ദയവായി 1 മുതൽ] ${maxTickets} [translate:വരെ ടിക്കറ്റുകളുടെ എണ്ണം നൽകുക.]`
  }
};

app.post('/chat', (req, res) => {
  try {
    const { message = '', userId } = req.body;
    if (!userId) return res.status(400).json({ reply: 'Missing userId.', quickReplies: [] });

    let userBooking = bookings.find(b => b.userId === userId);

    if (!userBooking && !completedBookings[userId]) {
      const langChoice = formatLanguageKey(message.trim());

      if (!message.trim() || !supportedLanguages.includes(langChoice)) {
        return res.json({
          reply: `Hello! Which language would you like to talk in? Please choose one: ${supportedLanguages.join(', ')}`,
          quickReplies: supportedLanguages,
        });
      }

      userBooking = { userId, step: 1, data: { language: langChoice } };
      bookings.push(userBooking);

      const langMsgs = messages[langChoice] || messages['Marathi'];

      return res.json({ reply: langMsgs.howCanIHelp, quickReplies: [] });
    }

    if (!userBooking) {
      return res.json({
        reply: `Hello! Please select a language: ${supportedLanguages.join(', ')}`,
        quickReplies: supportedLanguages,
      });
    }

    const lang = userBooking.data.language || 'Marathi';
    const langMsgs = messages[lang] || messages['Marathi'];

    switch (userBooking.step) {
      case 1:
        userBooking.data.name = message.trim();
        userBooking.step++;
        return res.json({
          reply: randomReply([
            langMsgs.askName,
            `Got it, ${userBooking.data.name}! ${langMsgs.askTickets}`,
          ]),
          quickReplies: Array.from({ length: maxTickets }, (_, i) => (i + 1).toString()),
        });

      case 2:
        const ticketCount = parseInt(message);
        if (isNaN(ticketCount) || ticketCount <= 0 || ticketCount > maxTickets) {
          return res.json({
            reply: langMsgs.invalidTickets,
            quickReplies: Array.from({ length: maxTickets }, (_, i) => (i + 1).toString()),
          });
        }
        userBooking.data.tickets = ticketCount;
        userBooking.step++;
        return res.json({
          reply: langMsgs.askDate,
          quickReplies: ["2025-12-25", "2026-01-01", "2026-05-15"],
        });

      case 3:
        if (!isValidDate(message)) {
          return res.json({
            reply: langMsgs.invalidDate,
            quickReplies: ["2025-12-25", "2026-01-01", "2026-05-15"],
          });
        }
        userBooking.data.date = message;
        userBooking.step++;
        return res.json({
          reply: langMsgs.askPlace,
          quickReplies: ["Delhi", "Kerala"],
        });

      case 4:
        if (!["Delhi", "Kerala"].includes(message)) {
          return res.json({
            reply: langMsgs.askPlace || "Please select the place you want to visit: Delhi or Kerala.",
            quickReplies: ["Delhi", "Kerala"],
          });
        }
        userBooking.data.visitPlace = message;
        userBooking.step++;
        if (message === "Delhi") {
          let prompt = "";
          switch (lang) {
            case 'Marathi': prompt = "तुम्हाला काय बुकिंग करायची आहे? खालीलपैकी एक निवडा."; break;
            case 'Hindi': prompt = "आप क्या बुक करना चाहेंगे? कृपया चुनें।"; break;
            case 'Punjabi': prompt = "ਤੁਸੀਂ ਕੀ ਬੁੱਕ ਕਰਨਾ ਚਾਹੁੰਦੇ ਹੋ? ਕਿਰਪਾ ਕਰਕੇ ਚੁਣੋ।"; break;
            case 'Malayalam': prompt = "[translate:നിങ്ങൾക്ക് എന്താണ് ബുക്ക് ചെയ്യേണ്ടത്? ദയവായി തിരഞ്ഞെടുക്കുക.]"; break;
            default: prompt = "What do you want to book? Please choose one.";
          }
          return res.json({
            reply: prompt,
            quickReplies: ["Tour Booking", "Car Booking"],
          });
        } else {
          const confirmMsg = langMsgs.confirmBooking(userBooking.data.name,
            userBooking.data.tickets, userBooking.data.date, message);
          userBooking.step++;
          return res.json({
            reply: confirmMsg,
            quickReplies: ["YES", "NO"],
          });
        }

      case 5:
        if (message === "Car Booking") {
          let carBookingMsg = "";
          switch (lang) {
            case 'Marathi': carBookingMsg = "आपण येथे कार बुक करू शकता: https://delhitourism.gov.in/carbooking"; break;
            case 'Hindi': carBookingMsg = "आप यहाँ कार बुक कर सकते हैं: https://delhitourism.gov.in/carbooking"; break;
            case 'Punjabi': carBookingMsg = "ਤੁਸੀਂ ਇੱਥੇ ਕਾਰ ਬੁਕ ਕਰ ਸਕਦੇ ਹੋ: https://delhitourism.gov.in/carbooking"; break;
            case 'Malayalam': carBookingMsg = "[translate:നിങ്ങൾക്ക് ഇവിടെ കാറു ബുക്കുചെയ്യാം: https://delhitourism.gov.in/carbooking]"; break;
            default: carBookingMsg = "You can book a car here: https://delhitourism.gov.in/carbooking";
          }
          userBooking.step = 99;
          return res.json({
            reply: carBookingMsg,
            quickReplies: ["Cancel my booking", "New booking"],
          });
        } else if (message === "Tour Booking") {
          let tourPrompt = "";
          switch (lang) {
            case 'Marathi': tourPrompt = "कृपया पर्यटन प्रकार निवडा:"; break;
            case 'Hindi': tourPrompt = "कृपया टूर प्रकार चुनें:"; break;
            case 'Punjabi': tourPrompt = "ਕਿਰਪਾ ਕਰਕੇ ਟੂਰ ਕਿਸਮ ਚੁਣੋ:"; break;
            case 'Malayalam': tourPrompt = "[translate:ദയവായി ടൂർ തരം തിരഞ്ഞെടുക്കുക:]"; break;
            default: tourPrompt = "Please select a tour type:";
          }
          return res.json({
            reply: tourPrompt,
            quickReplies: ["Dekho Meri Dilli", "Heritage Walk", "Outstation Tours"],
          });
        } else {
          let retryPrompt = "";
          switch (lang) {
            case 'Marathi': retryPrompt = "कृपया Tour Booking किंवा Car Booking निवडा."; break;
            case 'Hindi': retryPrompt = "कृपया Tour Booking या Car Booking चुनें।"; break;
            case 'Punjabi': retryPrompt = "ਕਿਰਪਾ ਕਰਕੇ Tour Booking ਜਾਂ Car Booking ਚੁਣੋ।"; break;
            case 'Malayalam': retryPrompt = "[translate:ദയവായി Tour Booking അല്ലെങ്കിൽ Car Booking തിരഞ്ഞെടുക്കുക.]"; break;
            default: retryPrompt = "Please choose Tour Booking or Car Booking.";
          }
          return res.json({
            reply: retryPrompt,
            quickReplies: ["Tour Booking", "Car Booking"],
          });
        }

      case 6:
        const tourOptions = ["Dekho Meri Dilli", "Heritage Walk", "Outstation Tours"];
        if (!tourOptions.includes(message)) {
          let retryMsg = "";
          switch (lang) {
            case 'Marathi': retryMsg = "कृपया वैध पर्यटक प्रकार निवडा."; break;
            case 'Hindi': retryMsg = "कृपया सही टूर प्रकार चुनें।"; break;
            case 'Punjabi': retryMsg = "ਕਿਰਪਾ ਕਰਕੇ ਠੀਕ ਟੂਰ ਕਿਸਮ ਚੁਣੋ।"; break;
            case 'Malayalam': retryMsg = "[translate:ദയവായി സാധുവായ ടൂർ തരം തിരഞ്ഞെടുക്കുക.]"; break;
            default: retryMsg = "Please select a valid tour type.";
          }
          return res.json({
            reply: retryMsg,
            quickReplies: tourOptions,
          });
        }

        if (message === "Dekho Meri Dilli") {
          userBooking.step = 7;
          return res.json({
            reply: "Please select one of the Dekho Meri Dilli tour options:",
            quickReplies: [
              "Dilli Ki Darohar (Morning Circuit-1)",
              "Dilli ka Rahasya (Morning Circuit-2)",
              "Rashtrapati Bhawan (Change of Guard Ceremony Morning Tour - Dilli ka Raisina House)"
            ]
          });
        }

        userBooking.data.tourType = message;
        let thankYouMsg = "";
        switch (lang) {
          case 'Marathi': thankYouMsg = `आपण '${message}' निवडली आहे. लवकरच आपल्याशी संपर्क साधला जाईल. धन्यवाद!`; break;
          case 'Hindi': thankYouMsg = `आपने '${message}' चुना है। हम जल्द ही आपसे संपर्क करेंगे। धन्यवाद!`; break;
          case 'Punjabi': thankYouMsg = `ਤੁਸੀਂ '${message}' ਚੁਣਿਆ ਹੈ। ਅਸੀਂ ਜਲਦੀ ਤੁਹਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰਾਂਗੇ। ਧੰਨਵਾਦ!`; break;
          case 'Malayalam': thankYouMsg = `[translate:നിങ്ങൾ '${message}' തിരഞ്ഞെടുക്കൽ. ഉടൻ ഞങ്ങൾ നിങ്ങളെ സമീപിക്കും. നന്ദി!]`; break;
          default: thankYouMsg = `You selected '${message}'. We will contact you soon. Thank you!`;
        }
        userBooking.step = 99;
        return res.json({
          reply: thankYouMsg,
          quickReplies: ["Cancel my booking", "New booking"],
        });

      case 7:
        const dilliMOptions = [
          "Dilli Ki Darohar (Morning Circuit-1)",
          "Dilli ka Rahasya (Morning Circuit-2)",
          "Rashtrapati Bhawan (Change of Guard Ceremony Morning Tour - Dilli ka Raisina House)"
        ];
        if (!dilliMOptions.includes(message)) {
          return res.json({
            reply: "Please select a valid Dekho Meri Dilli tour option:",
            quickReplies: dilliMOptions,
          });
        }

        const bookingLink = "https://delhitourism.gov.in/ebooking/DekhoMeriDilli";
        let optionMsg = `You selected ${message}. Book your ticket here: ${bookingLink}`;

        userBooking.step = 99;
        return res.json({
          reply: optionMsg,
          quickReplies: ["Cancel my booking", "New booking"],
        });

      case 99:
        if (message.toLowerCase().includes("cancel")) {
          delete completedBookings[userId];
          bookings = bookings.filter(b => b.userId !== userId);
          let cancelMsg = "";
          switch (lang) {
            case 'Marathi': cancelMsg = "बंद करण्यात आले."; break;
            case 'Hindi': cancelMsg = "रद्द कर दिया गया।"; break;
            case 'Punjabi': cancelMsg = "ਰੱਦ ਕਰ ਦਿੱਤਾ ਗਿਆ।"; break;
            case 'Malayalam': cancelMsg = "[translate:റദ്ദാക്കിയിരിക്കുന്നു.]"; break;
            default: cancelMsg = "Cancelled.";
          }
          return res.json({
            reply: cancelMsg,
            quickReplies: supportedLanguages,
          });
        }
        return res.json({
          reply: langMsgs.howCanIHelp,
          quickReplies: supportedLanguages,
        });

      default:
        bookings = bookings.filter(b => b.userId !== userId);
        return res.json({
          reply: langMsgs.howCanIHelp,
          quickReplies: supportedLanguages,
        });
    }
  } catch (error) {
    console.error("Error in chat handler:", error);
    return res.status(500).json({ reply: "Sorry, something went wrong on the server.", quickReplies: [] });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
